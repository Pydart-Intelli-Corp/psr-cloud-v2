module.exports=[204294,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_machine_statistics_route_actions_0a8e4e5c.js.map