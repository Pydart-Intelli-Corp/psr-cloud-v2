module.exports=[270285,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_%5Bdb-key%5D_Collection_SaveCollectionDetails_route_actions_8795e364.js.map