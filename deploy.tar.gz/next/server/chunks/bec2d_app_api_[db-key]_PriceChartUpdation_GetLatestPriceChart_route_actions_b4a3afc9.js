module.exports=[695792,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_api_%5Bdb-key%5D_PriceChartUpdation_GetLatestPriceChart_route_actions_b4a3afc9.js.map