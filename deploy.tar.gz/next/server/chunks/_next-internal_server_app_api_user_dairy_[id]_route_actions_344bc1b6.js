module.exports=[810610,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_dairy_%5Bid%5D_route_actions_344bc1b6.js.map