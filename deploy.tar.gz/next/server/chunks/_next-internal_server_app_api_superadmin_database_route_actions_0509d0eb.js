module.exports=[481264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_superadmin_database_route_actions_0509d0eb.js.map