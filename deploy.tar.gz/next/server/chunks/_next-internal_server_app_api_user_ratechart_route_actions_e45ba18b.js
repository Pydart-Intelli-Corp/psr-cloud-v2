module.exports=[740112,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_ratechart_route_actions_e45ba18b.js.map