module.exports=[592969,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_society_route_actions_d820ed6e.js.map