module.exports=[806498,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_farmer_upload_route_actions_6521f6d3.js.map