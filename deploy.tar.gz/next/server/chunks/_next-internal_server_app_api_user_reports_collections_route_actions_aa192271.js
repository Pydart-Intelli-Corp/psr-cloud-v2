module.exports=[52507,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_reports_collections_route_actions_aa192271.js.map