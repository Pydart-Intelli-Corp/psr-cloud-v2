module.exports=[638332,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_ratechart_assign_route_actions_056fb652.js.map