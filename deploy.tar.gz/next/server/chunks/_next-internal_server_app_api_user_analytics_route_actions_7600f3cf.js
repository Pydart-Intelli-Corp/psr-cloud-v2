module.exports=[160970,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_analytics_route_actions_7600f3cf.js.map