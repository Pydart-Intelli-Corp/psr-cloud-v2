module.exports=[525333,a=>{a.v("/_next/static/media/icon.376e8106.png")},821646,a=>{"use strict";let b={src:a.i(525333).default,width:126,height:117};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_0c8a77b8._.js.map