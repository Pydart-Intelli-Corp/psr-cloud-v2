module.exports=[128700,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_bmc_route_actions_62435ba8.js.map