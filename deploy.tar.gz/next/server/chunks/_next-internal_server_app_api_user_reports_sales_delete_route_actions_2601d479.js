module.exports=[78727,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_reports_sales_delete_route_actions_2601d479.js.map