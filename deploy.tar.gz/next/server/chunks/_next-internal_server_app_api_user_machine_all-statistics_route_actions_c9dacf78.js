module.exports=[637499,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_machine_all-statistics_route_actions_c9dacf78.js.map