module.exports=[721646,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_superadmin_approvals_route_actions_807fc406.js.map