module.exports=[228468,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_bmc_send-delete-otp_route_actions_b2449a56.js.map