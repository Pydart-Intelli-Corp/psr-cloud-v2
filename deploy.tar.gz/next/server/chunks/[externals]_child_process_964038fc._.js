module.exports=[233405,(e,r,s)=>{r.exports=e.x("child_process",()=>require("child_process"))}];

//# sourceMappingURL=%5Bexternals%5D_child_process_964038fc._.js.map