module.exports=[755751,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_society_%5Bid%5D_route_actions_5fd59c50.js.map