module.exports=[693833,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_superadmin_monitoring_stats_route_actions_e5a69597.js.map