module.exports=[870864,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_farmer_route_actions_75a9c104.js.map