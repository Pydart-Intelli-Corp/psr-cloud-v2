module.exports=[917796,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_forgot-password_route_actions_ada86dd3.js.map