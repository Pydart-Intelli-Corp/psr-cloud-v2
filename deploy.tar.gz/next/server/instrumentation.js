var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/_f90512a4._.js")
R.m(769449)
module.exports=R.m(769449).exports
