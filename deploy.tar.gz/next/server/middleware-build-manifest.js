globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/de9b9252074544c1.js",
    "static/chunks/e49035715a3b468c.js",
    "static/chunks/e7334ea60307a2c0.js",
    "static/chunks/f97b470b93526f60.js",
    "static/chunks/21e9480ab676c52e.js",
    "static/chunks/turbopack-724c64923834e628.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];